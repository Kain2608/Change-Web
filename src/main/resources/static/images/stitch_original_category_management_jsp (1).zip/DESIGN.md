# Design System Strategy: The Kinetic Ocean

## 1. Overview & Creative North Star: "The Kinetic Ocean"
This design system moves away from the static, boxy nature of traditional e-commerce. Our Creative North Star, **"The Kinetic Ocean,"** mirrors the fluidity and power of elite sports. We reject the "template" look in favor of an editorial-first approach that prioritizes high-velocity movement and premium depth.

By leveraging intentional asymmetry—such as oversized product imagery that breaks out of container bounds—and a sophisticated "Tonal Layering" strategy, we create an environment that feels both high-energy and deeply professional. We don't just sell gear; we curate a performance lifestyle.

## 2. Colors & Surface Architecture
The color palette is anchored by a vibrant, "oceanic" primary blue, supported by a sophisticated range of tinted neutrals that eliminate the need for harsh dividers.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a `surface-container-low` (#f1efff) section should sit on a `surface` (#f8f5ff) background to create a soft, natural distinction.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of frosted glass.
*   **Base:** `surface` (#f8f5ff)
*   **Secondary Content:** `surface-container-low` (#f1efff)
*   **Elevated Components:** `surface-container-highest` (#d9daff)
*   **Nesting Logic:** Place a `surface-container-lowest` (#ffffff) card on top of a `surface-container-low` section to create "lift" without relying on shadows.

### The "Glass & Gradient" Rule
To ensure the "Kinetic" feel, use Glassmorphism for floating elements (e.g., sticky navigation or filter chips). Use a semi-transparent `surface` color with a `backdrop-blur` of 20px. 
*   **Signature Textures:** Apply a subtle linear gradient from `primary` (#004fd8) to `primary-container` (#7d9cff) for main CTAs to inject visual "soul" and depth.

## 3. Typography: Editorial Authority
We utilize **Inter** not as a standard sans-serif, but as a high-contrast editorial tool.

*   **The Power Scale:** Use `display-lg` (3.5rem) for hero headlines to command attention. This conveys the "Energetic" pillar of the brand.
*   **The Information Layer:** `body-md` (0.875rem) handles the heavy lifting of product specs, while `label-md` (0.75rem) provides technical data in a clean, professional "all-caps" format for a tech-wear aesthetic.
*   **Hierarchy Note:** Always maintain a 2:1 ratio between headline and body size to ensure a clear visual anchor.

## 4. Elevation & Depth
Hierarchy is achieved through **Tonal Layering** rather than traditional structural lines.

*   **The Layering Principle:** Depth is "stacked." Avoid shadows on static elements. Instead, use the `surface-container` tiers.
*   **Ambient Shadows:** When an element must "float" (e.g., a cart modal), use an extra-diffused shadow: `box-shadow: 0 20px 40px rgba(40, 43, 81, 0.06);`. Note the shadow uses the `on-surface` color (#282b51) at low opacity, mimicking natural light.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` (#a8a9d7) at 20% opacity. 100% opaque borders are strictly forbidden.

## 5. Components & Primitives

### Buttons: High-Velocity Action
*   **Primary:** Uses the "Signature Gradient" (Primary to Primary-Container). Roundedness is strictly `md` (12px).
*   **Secondary:** Glass-style. Background: `surface-container-high` at 40% opacity with a subtle "Ghost Border."
*   **States:** On hover, primary buttons should scale 2% (`scale-102`) to simulate kinetic energy.

### Cards & Lists: The No-Divider Rule
*   **Product Cards:** Forbid the use of divider lines. Separate product name from price using a `1.5` (0.375rem) vertical spacing scale.
*   **Lists:** Use `surface-container-low` for alternating list items or simple `4` (1rem) spacing gaps.

### The "Product Spotlight" Component
A unique component for this system: An asymmetrical container where the product image overflows the top-right `xl` (1.5rem) corner, creating a sense of three-dimensional space and "breaking the grid."

### Input Fields
*   **Style:** `surface-container-lowest` background with a `2.5` (0.625rem) padding.
*   **Focus State:** A 2px "Ghost Border" using `primary` (#004fd8) at 40% opacity.

## 6. Do's and Don'ts

### Do:
*   **Do** use extreme white space (Spacing `16` or `20`) between major sections to let photography breathe.
*   **Do** overlap typography on top of product photography to create an editorial, magazine-style feel.
*   **Do** use `primary-dim` (#0045be) for interactive text links to ensure high-contrast accessibility.

### Don't:
*   **Don't** use black (#000000) for text. Always use `on-surface` (#282b51) for a sophisticated, deep-navy professional tone.
*   **Don't** use standard "drop shadows" with 0 blur. It breaks the "Kinetic Ocean" fluidity.
*   **Don't** use square corners. Every interactive element must adhere to the `md` (12px) or `full` (9999px) roundedness scale.

---
*Document Version: 1.0 | Prepared for ShopVnb Store*